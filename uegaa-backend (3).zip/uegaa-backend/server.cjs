const express = require("express");
const path = require("path");
const cors = require("cors");
const fs = require("fs");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

const formsPath = path.join(__dirname, "forms");

app.get("/fill/:service", (req, res) => {
  const { service } = req.params;
  let fileName = "";

  switch (service.toLowerCase()) {
    case "pan":
      fileName = "pan.pdf";
      break;
    case "aadhaar":
    case "aadhar":
      fileName = "aadhar.pdf";
      break;
    case "driving":
    case "drivinglicense":
    case "driving license":
      fileName = "driving_license.pdf";
      break;
    case "passport":
      fileName = "passport.pdf";
      break;
    default:
      return res.status(400).send("❌ Invalid service name");
  }

  const filePath = path.join(formsPath, fileName);

  // ✅ Check if the file actually exists
  if (!fs.existsSync(filePath)) {
    console.error("❌ File not found:", filePath);
    return res.status(404).send(`File not found for service: ${service}`);
  }

  // ✅ Send the file for download
  res.download(filePath, (err) => {
    if (err) {
      console.error("⚠️ Error while sending file:", err);
      res.status(500).send("Error preparing file for download");
    } else {
      console.log(`✅ Successfully sent: ${fileName}`);
    }
  });
});

app.get("/", (req, res) => {
  res.send("🚀 UEGAA Assistant Backend is running successfully!");
});

app.listen(PORT, () => {
  console.log(`✅ Server started at http://localhost:${PORT}`);
});
